
# dependencies
import math

import numpy as np
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

class Starfield:
    def __init__(self, state):
        self.state = state
        self.inputs = self.state.inputs

    def count_stars(self, *args):

        # create a list of possible cluster sizes, and empty output list
        if self.inputs.verbosity > 0:
            print("IN PROGRESS: Determining cluster number")

        # it can take incredibly long for this to run if the number of clusters is too high, so capped at 100
        if len(self.state.pixels_in_clusters) > 40:
            if self.inputs.verbosity > 0:
                print(f"IN PROGRESS: Trying up to 40 clusters!")
            cluster_size_list = range(2, 40)
        else:
            if self.inputs.verbosity > 0: print(f"Assessing up to {len(self.state.pixels_in_clusters)} clusters!")
            cluster_size_list = range(2, len(self.state.pixels_in_clusters))

        # loop through potential cluster sizes and produce silhouette scores
        silhouette_score_list = []
        for k in cluster_size_list:
            kmeans = KMeans(n_clusters=k, random_state=42)
            labels = kmeans.fit_predict(self.state.pixels_in_clusters)
            score = silhouette_score(self.state.pixels_in_clusters, labels)
            silhouette_score_list.append(score)

        # determine ideal number of clusters
        silhouette_score_list = np.array(silhouette_score_list)
        self.state.n_clusters = np.array(cluster_size_list)[np.argmax(silhouette_score_list)]

        # print outputs
        if self.inputs.verbosity > 0: print(f"{self.state.n_clusters} clusters detected in {self.inputs.frame_name}")

        # plot silhouette scores
        if self.inputs.verbosity > 1:
            plt.plot(cluster_size_list, silhouette_score_list, marker='o')
            plt.title("Silhouette Score vs Number of Clusters (KMeans)")
            plt.xlabel("Number of Clusters (k)")
            plt.ylabel("Silhouette Score")
            plt.grid(True)
            plt.show()

        return self

    def catalogue_properties(self, *args):

        def calculate_cluster_centroid(i_cluster):

            def create_bounding_box():
                perimeter_expansion = 30

                x_max = int(max(cluster_coords[:, 0]) + perimeter_expansion)
                x_min = int(min(cluster_coords[:, 0]) - perimeter_expansion)
                y_max = int(max(cluster_coords[:, 1]) + perimeter_expansion)
                y_min = int(min(cluster_coords[:, 1]) - perimeter_expansion)

                return x_max, x_min, y_max, y_min

            # find the indices of all the labels
            i_label = np.where(labels == i_cluster)

            # find the coordinates of all stars in a cluster
            cluster_coords = self.state.pixels_in_clusters[i_label]

            # create the bounding box, finding the maximum and minimum x/y co-ordinates
            max_x, min_x, max_y, min_y = create_bounding_box()

            # create an array with just the cropped star in it - this isn't used at the moment
            star_in_bounding_box = self.state.mono_array[min_y:max_y, min_x:max_x]

            # create a mark, where everything that is not the star is set to zero brightness
            masked = np.zeros_like(self.state.mono_array)
            masked[min_y:max_y, min_x:max_x] = self.state.mono_array[min_y:max_y, min_x:max_x]

            if self.inputs.verbosity > 3:
                plt.imshow(star_in_bounding_box, cmap='gray')
                plt.show()
                plt.imshow(masked, cmap='gray')
                plt.show()

            # find the intensity of the cluster
            cluster_intensity = np.sum(masked)

            # find the centroid by weighting against the intensity of each pixel
            y_indices, x_indices = np.indices(masked.shape)
            x_centroid = np.sum(x_indices * masked) / cluster_intensity
            y_centroid = np.sum(y_indices * masked) / cluster_intensity
            cluster_centroid = [float(x_centroid), float(y_centroid)]

            return cluster_centroid, cluster_intensity

        # 1: k means, labels for correct number of clusters
        kmeans = KMeans(n_clusters=self.state.n_clusters, random_state=42)
        labels = kmeans.fit_predict(self.state.pixels_in_clusters)

        centroid_list = np.empty((self.state.n_clusters, 2))
        intensity_list = np.empty(self.state.n_clusters)

        # pull out the centroid list - note that this will be unsorted!
        for ii in range(0, self.state.n_clusters):
            centroid, intensity = calculate_cluster_centroid(ii)
            centroid_list[ii, :] = centroid
            intensity_list[ii] = int(intensity) # NEVER GETS USED

        # pull out the centroid list - note that this will be unsorted!
        self.state.centroid_list = centroid_list
        # this may need updating to intensity_list list - the problem is that right now this is less robust than bincount(labels)
        self.state.magnitude_list = np.array(np.bincount(labels))

        # print outputs
        if self.inputs.verbosity > 1:
            print("Positions of stars:")
            print(self.state.centroid_list)
            print("Magnitude of stars:")
            print(self.state.magnitude_list)

        # plot identified stars
        if self.inputs.verbosity > 1:

            # create figure and load mono image
            plt.figure(figsize=(16, 12))
            plt.imshow(self.state.mono_array, cmap='gray')

            # plot a red circle around identified stars
            for i in range(self.state.n_clusters):
                x, y = self.state.centroid_list[i]
                marker_r = math.sqrt(self.state.magnitude_list[i]/math.pi)
                plt.scatter(x, y, facecolors='none', edgecolors='red', s=(marker_r+50))

            # plot identified stars 
            plt.title(f"{self.inputs.frame_name}: largest {self.state.n_clusters} stars detected inside search area")
            plt.xlabel("x")
            plt.ylabel("y")
            plt.gca().invert_yaxis()
            plt.grid(False)
            plt.show()

        return self
