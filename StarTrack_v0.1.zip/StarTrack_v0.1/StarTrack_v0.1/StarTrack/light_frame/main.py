
# dependencies
import numpy as np
from scipy.optimize import least_squares, fsolve, bisect
from StarTrack.light_frame.starfield import Starfield
from StarTrack.light_frame.star_alignment_vectors import StarAlignmentVectors
from StarTrack.light_frame.star_filter import StarFilter
from StarTrack.light_frame.frame_reader import FrameReader
from dataclasses import dataclass
from pathlib import Path
from dataclasses import replace

class LightFrame:
    # define inputs as a data class which is frozen
    @dataclass(frozen=True)
    class FrameInputs:
        # default inputs, where possible, are written below
        frame_name: str
        frame_directory: Path
        # inputs are ordered so that those without a default value go first
        verbosity: int = 0
        star_detect_radius: int = 20
        min_star_num: int = 50
        threshold_value: int = 252
        crop_factor: float = 0.85
        blur_radius: float = 3

    def __init__(self, **kwargs):
        # import inputs from dataclass
        self.inputs = self.FrameInputs(**kwargs)

        # intermediates
        self.threshold_array = None
        self.mono_array = None
        self.cluster_array = None

        # outputs
        self.n_clusters = None
        self.centroid_list = None
        self.magnitude_list = None
        self.ref_vectors = None
        self.ref_angles = None
        self.ref_star = None
        self.i_ref_star = None
        self.non_ref_stars = None

    # find the minium search radius required to find n clusters
    def solve_for_n_clusters(self, n_desired_clusters):

        # print update message
        if self.inputs.verbosity > 0: print(f"Assessing image star density to solve for detection threshold required to find {n_desired_clusters} largest stars")

        # fitness function which is passed through the least squares optimiser
        def fitness_function(x):

            # the code may not find any stars within the search radius - in this case, skip (ValueError)
            try:
                # try a new input, with an updated min_star_num
                self.inputs = replace(self.inputs, min_star_num=x, verbosity=0)

                # run processing and find residual
                StarFilter(self).local_density()
                Starfield(self).count_stars()
                residual = self.n_clusters - n_desired_clusters

            except ValueError:
                residual = -100
                pass

            return residual

        # read in the image
        FrameReader(self).preprocess_jpeg()

        # bisection solving to determine ideal star detection threshold inside search radius
        result = bisect(fitness_function, 20, 400)

        # return an optimum minimum star count
        return result

    # runs through the processing pipeline for a standard frame
    def process(self):
        # ReadImage(self.inputs).preprocess_jpeg()
        FrameReader(self).preprocess_jpeg()
        StarFilter(self).local_density()
        Starfield(self).count_stars()
        Starfield(self).catalogue_properties()
        StarAlignmentVectors(self).from_biggest_star()

        return self

    def process_with_solver(self, n_desired_clusters):

        optimal_min_star_radius = self.solve_for_n_clusters(n_desired_clusters) # calls FilterImage and CatalogueClusters to do this
        Starfield(self).catalogue_properties()
        StarAlignmentVectors(self).from_biggest_star()

        return optimal_min_star_radius

if __name__ == "__main__":
    data_dir = Path(r"D:\Astronomy\StarTrack\dev\raw_data_iris_nebula")
    light = LightFrame(frame_directory=data_dir, frame_name="iris_nebula_frame_1.jpg",verbosity=5,min_star_num = 129)
    light.process()
    # light.process_with_solver(n_desired_clusters=10)
