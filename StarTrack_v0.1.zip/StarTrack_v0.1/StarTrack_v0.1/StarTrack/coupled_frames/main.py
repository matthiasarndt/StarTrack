
# dependencies
import numpy as np
from skimage.transform import estimate_transform, warp

class CoupledFrames:
    def __init__(self, ref_frame, align_frame, *args):
        self.ref_frame = ref_frame
        self.addition_frame = align_frame
        self.coords_ref = None
        self.coords_addition = None
        self.addition_frame_aligned = None

    def ref_aligning_stars(self):

        self.coords_ref = self.calculate_aligning_stars(self.ref_frame, self.ref_frame)

        return self

    def addition_aligning_stars(self):

        self.coords_addition = self.calculate_aligning_stars(self.ref_frame, self.addition_frame)

        return self

    def align_addition_frame(self):

        # estimate transform matrices for "affine" image distortion assumption, using the coordinates calculated
        tform = estimate_transform('affine', self.coords_addition, self.coords_ref)

        # apply warp with inverese transform
        aligned = warp(self.addition_frame.mono_array, inverse_map=tform.inverse,
                       output_shape=self.addition_frame.mono_array.shape, preserve_range=True)

        # convert to 8 bit
        self.addition_frame_aligned = np.clip(aligned, 0, 255).astype(np.uint8)

        return self

    # the way this code is set up does mean that ref_aligning_stars is called every time, even though it doesn't need to be
    # this is not the most efficient way of writing this code, however it has been left this way to improve code readibility
    # and to keep all the relevant functions in one place
    # this will be re-written to reduce runtime!
    def align(self):
        self.ref_aligning_stars()
        self.addition_aligning_stars()
        self.align_addition_frame()

    # static method to calculate aligning stars for any two frames
    @staticmethod
    def calculate_aligning_stars(frame_main, frame_addition):

        def filter_coords(i_alignment_star):
            # i_alignment_star is the index of the aligning star. there are a total of 3 aligning stars:
            #   - the reference star angles list will have a length of 2. index 0 = star 2, index 1 = star 3)
            #   - star 1 is the reference star, which isn't in the list.
            #   - this step has been added for clarity
            search_index = i_alignment_star - 2

            # determine tolerance for determining the aligning stars
            tol = 0.01

            # the indices of each of the other two stars is found below:
            #   - it searches all catalogued stars and finds those with the correct angles from the reference star:
            i_ref_angle = np.where(np.abs(frame_addition.ref_angles - frame_main.ref_angles[search_index]) < tol)[0][0]

            # co-ordinates of non-reference stars flagged by the indices above are extracted
            non_ref_stars = frame_addition.non_ref_stars[i_ref_angle, :]

            # the indices in the main array of star centroids is found here, based on the exact star co-ordinates provided above
            i_alignment_star = np.where(frame_addition.centroid_list == non_ref_stars)[0][0]

            return i_alignment_star

        # calculate how many alignment stars are required
        n_alignments_stars = len(frame_main.centroid_list)

        # 1: the first alignment star is the reference star
        i_alignment_coords = [frame_addition.i_ref_star]

        # 2: the indices in the main array of star centroids is found here, based on the exact star co-ordinates provided above
        for i_star in range(1, n_alignments_stars):
            ii = filter_coords(i_star + 1)
            i_alignment_coords.append(ii)

        # 3: using the indices from the main array above, the alignment co-ordinates are determined
        alignment_coords = frame_addition.centroid_list[i_alignment_coords]

        # 5: return a 3x1 numpy array with alignment co-ordinates
        return alignment_coords

