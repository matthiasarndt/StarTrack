
# dependencies
import os
from pathlib import Path
from StarTrack import AstroPhoto

# determine inputs
run_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = Path(run_dir) / 'raw_data_iris_nebula'
n_aligning_stars = 5

# create iris nebula object from astro photo, and declare variables of interest
iris_nebula = AstroPhoto(data_directory=data_dir, n_aligning_stars=n_aligning_stars)

# process iris nebula to get results!
iris_nebula.align_frames()
iris_nebula.stack_aligned_frames()